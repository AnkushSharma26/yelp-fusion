<?php
if(!defined("ABSPATH"))exit;
if(!is_user_logged_in())
{
	return;
}
else
{
	$access_granted = false;
	foreach ($user_role_permission as $permissions) {
		if(current_user_can($permissions))
		{
			$access_granted = true;
			break;
		}
	}
	if(!$access_granted)
	{
		return;
	}
	else
	{
		setting_page();
		if(isset($_GET['page']))
		{
					global $wpdb;
					$yelp_result = $wpdb->get_results("SELECT * FROM wp_parent_reviews_for_gyhf where pagename='yelp_reviews'");
					$apiyelp = $_POST['apikey'];
					$secretyelp = $_POST['secretkey'];
					$yelptitle = $_POST['reviewstitle'];
					if(!empty($yelp_result))
					{
						if(isset($_POST['action_submit_yelp']))
						{
							global $wpdb;
							$yelp_query ="UPDATE wp_parent_reviews_for_gyhf SET APIKey ='$apiyelp',SecretKey='$secretyelp',ReviewTitle='$yelptitle' where pagename='yelp_reviews'";
					   		 $result_yelp = $wpdb->query($yelp_query);
					   		 if($result_yelp == true)
					   		 {
					   		 	?>
								<div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible"> 
								<p><strong>Updated.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
								<?php
					   		 }
					   		 else
					   		 {
					   		 	?>
								<div id="setting-error-settings_updated" class="error settings-error notice is-dismissible"> 
								<p><strong>Oops!! Already In Use.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
								<?php
					   		 }
						}
					}
					else
					{
						if(isset($_POST['action_submit_yelp']))
						{
							global $wpdb;
							if($wpdb->insert(
								'wp_parent_reviews_for_gyhf',
								array(
						                'APIKey' => $apiyelp,
									    'SecretKey' => $secretyelp,
									   // 'NoofReviews' => $noofreviews,
									    'ReviewTitle' => $yelptitle,
									    'pagename' => 'yelp_reviews'
						            )
								) == true);
						}
					}
					
		}	
		?>
		<script type="text/javascript">
				jQuery(document).ready(function(jQuery){
					jQuery("#ux_frm_form").validate(
					{
			            rules: {
			            	checkbox_yelp: {
			            		required:true
			            	},
			                apikey: {
			                    required:true
			                },
			                secretkey: {
			                    required:true
			                },
			                reviewstitle: {
			                    required:true,
			                    lettersonly: true
			                }
			            },
			            messages:{
			            	checkbox_yelp:
			            	{
			            		required: "Enable/Desable Yelp"
			            	},
			                apikey: 
			                {
			                	required: "Please Insert Your API Here"
			                },
			                secretkey: 
			                {
			                	required:"Please Insert Your Secret Key"
			                },
			                reviewstitle: 
			                {
			                	required:"Please Provide your Review Title"
			                }			        	
			            }
					});
				});
				jQuery.validator.addMethod("lettersonly", function(value, element) 
				{
				  return this.optional(element) || /[a-z]+$/i.test(value);
				}, "You can't Enter Numeric Value. Letters only please"); 
			</script>
			<script type="text/javascript">
			    function ShowHideyelp(ux_txt_id_check_yelp) {
			        var dvPassport = document.getElementById("dv_form_yelp");
			        dv_form_yelp.style.display = ux_txt_id_check_yelp.checked ? "block" : "none";
			    }
			</script>
			<div class="container-width">
				<form id="ux_frm_form" method="post" action="">
						<div class="checkbox_area">
							<label class="check-label">Enable/Desable:</label>
							<input type="checkbox" name="checkbox_yelp" class="ux_chk_checkbox" id="ux_txt_id_check_yelp" onclick="ShowHideyelp(this)">
						</div>
					<div class="form-data" id="dv_form_yelp" style="display: none">
						<div class="div-form-api">
							<label class="label-api">API Key:</label>
							<input type="text" name="apikey" class="form-control" id="ux_txt_api_div" placeholder="Please insert your API here*****" value="<?php echo $_POST['apikey'] ? $_POST['apikey'] : $yelp_result[0]->APIKey;?>">
							<p class="date-time-doc doc-timr"><a href="https://www.google.com">Google API</a>.</p>
						</div>
						<div class="div-form-api-secret">
							<label class="label-api-secret">Secret Key:</label>
							<input type="text" name="secretkey" class="form-control" id="ux_txt_api_secret" placeholder="Please insert your API Secret here*****" value="<?php echo $_POST['secretkey'] ? $_POST['secretkey'] : $yelp_result[0]->SecretKey;?>">
							<p class="date-time-doc doc-timr"><a href="https://www.google.com">Google API Secret</a>.</p>
						</div>
						<!-- <div class="div-form-no-of-reviews">
							<label class="label-no-of-reviews">Number of Reviews:</label>
							<input type="text" name="no-of-reviews" class="form-control" id="ux_txt_no_of_reviews" placeholder="Number of Reviews">
						</div> -->
						<div class="div-form-reviews-title">
							<label class="label-reviews-title">Review Title:</label>
							<input type="text" name="reviewstitle" class="form-control" id="ux_txt_reviews_title" placeholder="Please Write Your Review Title" value="<?php echo $_POST['reviewstitle'] ? $_POST['reviewstitle'] : $yelp_result[0]->ReviewTitle;?>">
						</div>
					</div>
					<div class="submit-buttons">
						<div id="ux_btn_submit_form">
						<input type="submit" name="action_submit_yelp" class="button button-primary ux_btn_plus_sub" id="class_id_submit" value="Save Changes">
						</div>	
					</div>
				</form>
			</div>
		<?php
	}
}
?>