<?php
if(!defined("ABSPATH"))exit;
if(!is_user_logged_in())
{
	return;
}
else
{
	$access_granted = false;
	foreach ($user_role_permission as $permissions) {
		if(current_user_can($permissions))
		{
			$access_granted = true;
			break;
		}
	}
	if(!$access_granted)
	{
		return;
	}
	else
	{
		setting_page();
		if(isset($_GET['page']))
		{
		
					global $wpdb;
					$fb_result = $wpdb->get_results("SELECT * FROM wp_parent_reviews_for_gyhf where pagename='fb_reviews'");
					$apifb = $_POST['apikeyfb'];
					$secrefb = $_POST['secretkeyfb'];
					$healthfb = $_POST['reviewsfb'];
					if(!empty($fb_result))
					{
						if(isset($_POST['action_submit_fb']))
						{
							global $wpdb;
							$fb_query ="UPDATE wp_parent_reviews_for_gyhf SET APIKey ='$apifb',SecretKey='$secrefb',ReviewTitle='$healthfb' where pagename='fb_reviews'";
					   		 $result_fb = $wpdb->query($fb_query);
					   		 if($result_fb == true)
					   		 {
					   		 	?>
								<div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible"> 
								<p><strong>Updated.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
								<?php
					   		 }
					   		 else
					   		 {
					   		 	?>
								<div id="setting-error-settings_updated" class="error settings-error notice is-dismissible"> 
								<p><strong>Oops!! Already In Use.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
								<?php
					   		 }
						}
					}
					else
					{
						if(isset($_POST['action_submit_fb']))
						{
							global $wpdb;
							if($wpdb->insert(
								'wp_parent_reviews_for_gyhf',
								array(
						                'APIKey' => $apifb,
									    'SecretKey' => $secrefb,
									   // 'NoofReviews' => $noofreviews,
									    'ReviewTitle' => $healthfb,
									    'pagename' => 'fb_reviews'
						            )
								) == true);
						}
					}
					
		}
		?>
		<script type="text/javascript">
				jQuery(document).ready(function(jQuery){
					jQuery("#ux_frm_form").validate(
					{
			            rules: {
			                apikeyfb: {
			                    required:true,
			                },
			                secretkeyfb: {
			                    required:true
			                },
			                reviewsfb: {
			                    required:true,
			                    lettersonly: true
			                }
			            },
			            messages:{
			                apikeyfb: 
			                {
			                	required: "Please Insert Your API Here"
			                },
			                secretkeyfb: 
			                {
			                	required:"Please Insert Your Secret Key"
			                },
			                reviewsfb: 
			                {
			                	required:"Please Provide your Review Title"
			                }			        	
			            }
					});
				});
				jQuery.validator.addMethod("lettersonly", function(value, element) 
				{
				  return this.optional(element) || /[a-z]+$/i.test(value);
				}, "You can't Enter Numeric Value. Letters only please"); 
			</script>
			<div class="container-width">
				<form id="ux_frm_form" method="post" action="">
					<div class="form-data">
						<div class="div-form-api">
							<label class="label-api">API Key:</label>
							<input type="text" name="apikeyfb" class="form-control" id="ux_txt_api_div" placeholder="Please insert your API here*****" value="<?php echo $_POST['apikeyfb'] ? $_POST['apikeyfb'] : $fb_result[0]->APIKey;?>">
							<p class="date-time-doc doc-timr"><a href="https://www.google.com">Google API</a>.</p>
						</div>
						<div class="div-form-api-secret">
							<label class="label-api-secret">Secret Key:</label>
							<input type="text" name="secretkeyfb" class="form-control" id="ux_txt_api_secret" placeholder="Please insert your API Secret here*****" value="<?php echo $_POST['secretkeyfb'] ? $_POST['secretkeyfb'] : $fb_result[0]->SecretKey;?>">
							<p class="date-time-doc doc-timr"><a href="https://www.google.com">Google API Secret</a>.</p>
						</div>
						<!-- <div class="div-form-no-of-reviews">
							<label class="label-no-of-reviews">Number of Reviews:</label>
							<input type="text" name="no-of-reviews" class="form-control" id="ux_txt_no_of_reviews" placeholder="Number of Reviews">
						</div> -->
						<div class="div-form-reviews-title">
							<label class="label-reviews-title">Review Title:</label>
							<input type="text" name="reviewsfb" class="form-control" id="ux_txt_reviews_title" placeholder="Please Write Your Review Title" value="<?php echo $_POST['reviewsfb'] ? $_POST['reviewsfb'] : $fb_result[0]->ReviewTitle;?>">
						</div>
					</div>
					<div class="submit-buttons">
						<div id="ux_btn_submit_form">
						<input type="submit" name="action_submit_fb" class="button button-primary ux_btn_plus_sub" id="class_id_submit" value="Save Changes">
						</div>	
					</div>
				</form>
			</div>
		<?php
	}
}
?>