<?php
if(!defined("ABSPATH"))exit;
if(!is_user_logged_in())
{
	return;
}
else
{
	$access_granted = false;
	foreach ($user_role_permission as $permissions) {
		if(current_user_can($permissions))
		{
			$access_granted = true;
			break;
		}
	}
	if(!$access_granted)
	{
		return;
	}
	else
	{


		//Sidebar Menus

		add_menu_page("setting_page","GYHF Reviews","read","setting_page","setting_page");
		add_submenu_page("setting_page","Google Business","Google Business","read","google_reviews","google_reviews");
		add_submenu_page("setting_page","Yelp","Yelp","read","yelp_reviews","yelp_reviews");
		add_submenu_page("setting_page","Healthgrades","Healthgrades","read","healthgrades_reviews","healthgrades_reviews");
		add_submenu_page("setting_page","Facebook Reviews","Facebook Reviews","read","fb_reviews","fb_reviews");


		/*
		Function Name: setting_page
		Description: This function is used to create and display a pages and there content into the frontend
		Paramenter: $current
		Created By: Acutweb Team
		Created On: 26-02-2018
		*/

		if(!function_exists("setting_page"))
		{
			function setting_page( $current = 'google_reviews' ) 
			{
				if('google_reviews' == true)
				{	
				    $tabs = array(
				    	'setting_page'   => __( 'Settings', 'wp-reviews-online' ), 
				        'google_reviews'   => __( 'Google Business', 'wp-reviews-online' ), 
				        'yelp_reviews'  => __( 'Yelp', 'wp-reviews-online' ),
				        'healthgrades_reviews'  => __( 'Healthgrades', 'wp-reviews-online' ),
				        'fb_reviews'  => __( 'Facebook Reviews', 'wp-reviews-online' )
				    );
	    			$html = '<h2 class="nav-tab-wrapper">';
				    foreach( $tabs as $tab => $name )
				    {

				        //$class = ( $tab == $current ) ? 'nav-tab-active' : '';
				        $html .= '<a class="nav-tab ' . $class . '" href="?page=' . $tab . '">' . $name . '</a>';
				    }
	    			$html .= '</h2>';
	   				 echo $html;
				}
				else
				{
					include (ONLINE_REVIEWS_DIR_PATH."views/settings.php");
				}
			}
		}


		/*
		Function Name: google_reviews
		Description: This function is used to create and display a pages and there content into the frontend
		Paramenter: No
		Created By: Acutweb Team
		Created On: 26-02-2018
		*/

		if(!function_exists("google_reviews"))
		{
			function google_reviews()
			{
				$user_role_permission = array("manage_options","edit_plugins","edit_posts","publish_posts","publish_pages","edit_pages","read");
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."includes/translation.php"))
				{
					include ONLINE_REVIEWS_DIR_PATH."includes/translation.php";
				}
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."views/google-reviews.php"))
				{
					include_once ONLINE_REVIEWS_DIR_PATH."views/google-reviews.php";
				}
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."includes/queries.php"))
				{
					include_once ONLINE_REVIEWS_DIR_PATH."includes/queries.php";
				}
			}
		}


		/*
		Function Name: yelp_reviews
		Description: This function is used to create and display a pages and there content into the frontend
		Paramenter: No
		Created By: Acutweb Team
		Created On: 26-02-2018
		*/

		if(!function_exists("yelp_reviews"))
		{
			function yelp_reviews()
			{
				$user_role_permission = array("manage_options","edit_plugins","edit_posts","publish_posts","publish_pages","edit_pages","read");
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."includes/translation.php"))
				{
					include ONLINE_REVIEWS_DIR_PATH."includes/translation.php";
				}
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."views/yelp-review.php"))
				{
					include_once ONLINE_REVIEWS_DIR_PATH."views/yelp-review.php";
				}
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."includes/queries.php"))
				{
					include_once ONLINE_REVIEWS_DIR_PATH."includes/queries.php";
				}
			}
		}





		/*
		Function Name: healthgrades_reviews
		Description: This function is used to create and display a pages and there content into the frontend
		Paramenter: No
		Created By: Acutweb Team
		Created On: 26-02-2018
		*/

		if(!function_exists("healthgrades_reviews"))
		{
			function healthgrades_reviews()
			{
				$user_role_permission = array("manage_options","edit_plugins","edit_posts","publish_posts","publish_pages","edit_pages","read");
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."includes/translation.php"))
				{
					include ONLINE_REVIEWS_DIR_PATH."includes/translation.php";
				}
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."views/healthgrades-reviews.php"))
				{
					include_once ONLINE_REVIEWS_DIR_PATH."views/healthgrades-reviews.php";
				}
			}
		}



		/*
		Function Name: fb_reviews
		Description: This function is used to create and display a pages and there content into the frontend
		Paramenter: No
		Created By: Acutweb Team
		Created On: 26-02-2018
		*/

		if(!function_exists("fb_reviews"))
		{
			function fb_reviews()
			{
				$user_role_permission = array("manage_options","edit_plugins","edit_posts","publish_posts","publish_pages","edit_pages","read");
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."includes/translation.php"))
				{
					include ONLINE_REVIEWS_DIR_PATH."includes/translation.php";
				}
				if(file_exists(ONLINE_REVIEWS_DIR_PATH."views/fb-reviews.php"))
				{
					include_once ONLINE_REVIEWS_DIR_PATH."views/fb-reviews.php";
				}
			}
		}


	}
}

?>