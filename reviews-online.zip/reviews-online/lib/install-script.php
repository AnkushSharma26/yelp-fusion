<?php
if(!defined("ABSPATH"))exit;
if(!is_user_logged_in())
{
	return;
}
else
{
	$access_granted = false;
	foreach ($user_role_permission as $permissions) {
		if(current_user_can($permissions))
		{
			$access_granted = true;
			break;
		}
	}
	if(!$access_granted)
	{
		return;
	}
	else
	{
   		require_once ABSPATH . "wp-admin/includes/upgrade.php";
		
		/*
		Function Name: call_parent_table_prefix
		Descrition: This function is used to create a table.
		Created By: Acutweb Team
		Created On: 27-02-2018
		*/

		if(!function_exists("call_parent_table_prefix"))
		{
			function call_parent_table_prefix()
			{
				$sql = "CREATE TABLE IF NOT EXISTS " . parent_review_table() . "
	            (
	              `id` int(10) NOT NULL AUTO_INCREMENT,
	               `APIKey` varchar(255) NOT NULL,
	               `SecretKey` varchar(255) NOT NULL,
	               `ReviewTitle` Text NOT NULL,
	               `pagename` varchar(50) NOT NULL,
	               PRIMARY KEY (`id`)
	            )
	            ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COLLATE= utf8_general_ci";
	            dbDelta($sql); 
			}
			call_parent_table_prefix();
		}
	}
}


?>